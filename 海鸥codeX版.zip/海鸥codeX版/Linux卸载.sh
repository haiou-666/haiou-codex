#!/usr/bin/env node
// Generated at release-build time. Do not distribute this source file.
const PUBLIC_KEY_B64 = "xJqcYBBp/8WEfXFUSZqr6NLYJq8Vh8cUMs07k5gKOmE=";
const PAYLOAD_KEY_B64 = "M3+aDqdqmKk2aJK1A4erJtZJrrJQAKEZwqvXpVvr5fg=";
const PRODUCT_VERSION = "4.5.0";
const PUBLIC_KEY_SHA256 = "96f968dfa56108967c6557120733ab6be550e39cd98d2dec2f8d59621916e9a8";
// Generated constants are prepended by build-cross-platform.ps1.

const crypto = require("node:crypto");
const fs = require("node:fs");
const fsp = require("node:fs/promises");
const os = require("node:os");
const path = require("node:path");
const readline = require("node:readline/promises");
const zlib = require("node:zlib");

const ACTION = "uninstall";
const PRODUCT = "Seagull Codex Edition";
const MANIFEST_NAME = "package-manifest.json";
const SIGNATURE_NAME = "package-manifest.sig";
const SKILLS = [
  "seagull-reverse",
  "seagull-pentest",
  "seagull-memory",
  "seagull-lab",
  "seagull-game-security",
  "seagull-license-security",
];
const MANAGED_BEGIN = "<!-- CTF-LAB-2.0:BEGIN -->";
const MANAGED_END = "<!-- CTF-LAB-2.0:END -->";
const args = new Set(process.argv.slice(2));
const noPause = args.has("--no-pause") || process.env.SEAGULL_NO_PAUSE === "1";

class IntegrityError extends Error {}

function banner() {
  console.log("=".repeat(55));
  console.log(`  海鸥 codeX 版 v${PRODUCT_VERSION}`);
  console.log("  海鸥 API 中转");
  console.log("  https://zz.aiapi2025.top");
  console.log("=".repeat(55));
}

function sha256(data) {
  return crypto.createHash("sha256").update(data).digest("hex");
}

async function sha256File(file) {
  const hash = crypto.createHash("sha256");
  await new Promise((resolve, reject) => {
    const stream = fs.createReadStream(file);
    stream.on("data", chunk => hash.update(chunk));
    stream.on("error", reject);
    stream.on("end", resolve);
  });
  return hash.digest("hex");
}

function globRegex(pattern) {
  let value = pattern.replace(/\\/g, "/");
  value = value.replace(/[.+^${}()|[\]\\]/g, "\\$&");
  value = value.replace(/\*\*/g, "\u0000");
  value = value.replace(/\*/g, "[^/]*");
  value = value.replace(/\u0000/g, ".*");
  value = value.replace(/\?/g, ".");
  return new RegExp(`^${value}$`, "i");
}

function ignored(relative, patterns) {
  const normalized = relative.replace(/\\/g, "/");
  return patterns.some(pattern => globRegex(pattern).test(normalized));
}

async function walkFiles(root, patterns) {
  const result = new Map();
  async function walk(current) {
    const entries = await fsp.readdir(current, { withFileTypes: true });
    for (const entry of entries) {
      const full = path.join(current, entry.name);
      const relative = path.relative(root, full).split(path.sep).join("/");
      if (entry.isSymbolicLink()) continue;
      if (entry.isDirectory()) await walk(full);
      else if (entry.isFile() && !ignored(relative, patterns)) result.set(relative, full);
    }
  }
  await walk(root);
  return result;
}

function ed25519PublicKey(raw) {
  const spkiPrefix = Buffer.from("302a300506032b6570032100", "hex");
  return crypto.createPublicKey({ key: Buffer.concat([spkiPrefix, raw]), format: "der", type: "spki" });
}

async function verifyRelease(coreDir) {
  const manifestPath = path.join(coreDir, MANIFEST_NAME);
  const signaturePath = path.join(coreDir, SIGNATURE_NAME);
  let raw;
  let signature;
  try {
    raw = await fsp.readFile(manifestPath);
    signature = Buffer.from((await fsp.readFile(signaturePath, "ascii")).trim(), "base64");
  } catch (error) {
    throw new IntegrityError(`签名清单不存在或无法读取：${error.message}`);
  }
  const publicRaw = Buffer.from(PUBLIC_KEY_B64, "base64");
  if (!crypto.verify(null, raw, ed25519PublicKey(publicRaw), signature)) {
    throw new IntegrityError("发布签名无效。");
  }
  let manifest;
  try {
    manifest = JSON.parse(raw.toString("utf8"));
  } catch (error) {
    throw new IntegrityError(`签名清单格式损坏：${error.message}`);
  }
  if (manifest.product !== PRODUCT || manifest.version !== PRODUCT_VERSION || manifest.mode !== "packed") {
    throw new IntegrityError("启动器与数据包版本或产品标识不匹配。");
  }
  if (manifest.public_key_sha256 !== PUBLIC_KEY_SHA256 || sha256(publicRaw) !== PUBLIC_KEY_SHA256) {
    throw new IntegrityError("发布者公钥指纹不匹配。");
  }
  const patterns = Array.isArray(manifest.ignored_patterns) ? manifest.ignored_patterns : [];
  const expected = new Map((manifest.files || []).map(entry => [entry.path, entry]));
  const actual = await walkFiles(coreDir, patterns);
  const issues = [];
  for (const relative of expected.keys()) if (!actual.has(relative)) issues.push(`缺失：${relative}`);
  for (const relative of actual.keys()) if (!expected.has(relative)) issues.push(`新增：${relative}`);
  for (const [relative, entry] of expected.entries()) {
    const file = actual.get(relative);
    if (!file) continue;
    const stat = await fsp.stat(file);
    if (stat.size !== Number(entry.size)) issues.push(`大小变化：${relative}`);
    else if ((await sha256File(file)).toLowerCase() !== String(entry.sha256).toLowerCase()) issues.push(`内容变化：${relative}`);
  }
  if (issues.length) throw new IntegrityError(`检测到文件被修改，拒绝运行：\n${issues.slice(0, 30).map(x => `  - ${x}`).join("\n")}`);
  return manifest;
}

const crcTable = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    table[n] = c >>> 0;
  }
  return table;
})();

function crc32(buffer) {
  let crc = 0xffffffff;
  for (const byte of buffer) crc = crcTable[(crc ^ byte) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

function safeArchivePath(name) {
  const normalized = name.replace(/\\/g, "/");
  if (!normalized || normalized.startsWith("/") || /^[A-Za-z]:/.test(normalized)) throw new IntegrityError(`数据包包含非法路径：${name}`);
  const parts = normalized.split("/").filter(Boolean);
  if (parts.some(part => part === "..")) throw new IntegrityError(`数据包包含非法路径：${name}`);
  return parts;
}

async function extractZip(buffer, destination) {
  let eocd = -1;
  const minimum = Math.max(0, buffer.length - 65557);
  for (let offset = buffer.length - 22; offset >= minimum; offset--) {
    if (buffer.readUInt32LE(offset) === 0x06054b50) { eocd = offset; break; }
  }
  if (eocd < 0) throw new IntegrityError("数据包 ZIP 目录损坏。");
  const entries = buffer.readUInt16LE(eocd + 10);
  let cursor = buffer.readUInt32LE(eocd + 16);
  for (let index = 0; index < entries; index++) {
    if (buffer.readUInt32LE(cursor) !== 0x02014b50) throw new IntegrityError("数据包 ZIP 中央目录损坏。");
    const method = buffer.readUInt16LE(cursor + 10);
    const expectedCrc = buffer.readUInt32LE(cursor + 16);
    const compressedSize = buffer.readUInt32LE(cursor + 20);
    const uncompressedSize = buffer.readUInt32LE(cursor + 24);
    const nameLength = buffer.readUInt16LE(cursor + 28);
    const extraLength = buffer.readUInt16LE(cursor + 30);
    const commentLength = buffer.readUInt16LE(cursor + 32);
    const localOffset = buffer.readUInt32LE(cursor + 42);
    const name = buffer.subarray(cursor + 46, cursor + 46 + nameLength).toString("utf8");
    cursor += 46 + nameLength + extraLength + commentLength;
    const parts = safeArchivePath(name);
    if (!parts.length) continue;
    const target = path.join(destination, ...parts);
    if (name.endsWith("/")) { await fsp.mkdir(target, { recursive: true }); continue; }
    if (buffer.readUInt32LE(localOffset) !== 0x04034b50) throw new IntegrityError(`ZIP 本地条目损坏：${name}`);
    const localNameLength = buffer.readUInt16LE(localOffset + 26);
    const localExtraLength = buffer.readUInt16LE(localOffset + 28);
    const dataStart = localOffset + 30 + localNameLength + localExtraLength;
    const compressed = buffer.subarray(dataStart, dataStart + compressedSize);
    let data;
    if (method === 0) data = Buffer.from(compressed);
    else if (method === 8) data = zlib.inflateRawSync(compressed);
    else throw new IntegrityError(`不支持的 ZIP 压缩算法 ${method}：${name}`);
    if (data.length !== uncompressedSize || crc32(data) !== expectedCrc) throw new IntegrityError(`ZIP 条目校验失败：${name}`);
    await fsp.mkdir(path.dirname(target), { recursive: true });
    await fsp.writeFile(target, data);
  }
}

async function verifyLauncherLock(root, coreDir) {
  let raw;
  let signature;
  let manifest;
  try {
    raw = await fsp.readFile(path.join(coreDir, "launcher-manifest.json"));
    signature = Buffer.from((await fsp.readFile(path.join(coreDir, "launcher-manifest.sig"), "ascii")).trim(), "base64");
    const publicRaw = Buffer.from(PUBLIC_KEY_B64, "base64");
    if (!crypto.verify(null, raw, ed25519PublicKey(publicRaw), signature)) throw new Error("signature mismatch");
    manifest = JSON.parse(raw.toString("utf8"));
  } catch (error) {
    throw new IntegrityError(`启动器身份锁无效：${error.message}`);
  }
  if (manifest.type !== "unified-launcher-lock" || manifest.product !== PRODUCT) throw new IntegrityError("启动器身份锁产品标识无效。");
  if (manifest.version !== PRODUCT_VERSION || manifest.public_key_sha256 !== PUBLIC_KEY_SHA256) throw new IntegrityError("启动器身份锁版本或发布者指纹不匹配。");
  const expected = new Map((manifest.files || []).map(entry => [entry.path, entry]));
  const actual = new Map();
  for (const entry of await fsp.readdir(root, { withFileTypes: true })) {
    if (entry.isFile()) actual.set(entry.name, path.join(root, entry.name));
  }
  const issues = [];
  for (const name of expected.keys()) if (!actual.has(name)) issues.push(`启动器缺失：${name}`);
  for (const name of actual.keys()) if (!expected.has(name)) issues.push(`额外入口：${name}`);
  for (const [name, entry] of expected.entries()) {
    const file = actual.get(name);
    if (!file) continue;
    const stat = await fsp.stat(file);
    if (stat.size !== Number(entry.size)) issues.push(`入口大小变化：${name}`);
    else if ((await sha256File(file)).toLowerCase() !== String(entry.sha256).toLowerCase()) issues.push(`入口内容变化：${name}`);
  }
  const currentName = path.basename(__filename);
  if (!expected.has(currentName)) issues.push(`当前入口不在官方清单：${currentName}`);
  if (issues.length) throw new IntegrityError(`启动器身份校验失败：\n${issues.slice(0, 30).map(x => `  - ${x}`).join("\n")}`);
  return String(manifest.release_id || "");
}
async function decryptPayload(coreDir, manifest) {
  const packed = await fsp.readFile(path.join(coreDir, "payload.pkg"));
  if (packed.length < 33 || packed.subarray(0, 5).toString("ascii") !== "SGPK1") throw new IntegrityError("加密数据包头无效。");
  const nonce = packed.subarray(5, 17);
  const encrypted = packed.subarray(17);
  const ciphertext = encrypted.subarray(0, encrypted.length - 16);
  const tag = encrypted.subarray(encrypted.length - 16);
  try {
    const decipher = crypto.createDecipheriv("aes-256-gcm", Buffer.from(PAYLOAD_KEY_B64, "base64"), nonce);
    decipher.setAAD(Buffer.from(`${PRODUCT}|${manifest.version}`, "utf8"));
    decipher.setAuthTag(tag);
    const plaintext = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
    const temp = await fsp.mkdtemp(path.join(os.tmpdir(), "seagull-codex-"));
    await extractZip(plaintext, temp);
    return temp;
  } catch (error) {
    if (error instanceof IntegrityError) throw error;
    throw new IntegrityError(`数据包认证或解密失败：${error.message}`);
  }
}

function codexHome() {
  return path.resolve(process.env.CTFLAB_CODEX_HOME || process.env.CODEX_HOME || path.join(os.homedir(), ".codex"));
}

function timestamp() {
  return new Date().toISOString().replace(/[-:TZ.]/g, "").slice(0, 17);
}

async function exists(file) {
  try { await fsp.access(file); return true; } catch { return false; }
}

async function backupManaged(home, action) {
  const backup = path.join(home, "backups", `seagull-${action}-${timestamp()}`);
  await fsp.mkdir(backup, { recursive: true });
  for (const name of ["AGENTS.md", "config.toml"]) {
    const source = path.join(home, name);
    if (await exists(source)) await fsp.copyFile(source, path.join(backup, name));
  }
  for (const skill of SKILLS) {
    const source = path.join(home, "skills", skill);
    if (await exists(source)) await fsp.cp(source, path.join(backup, "skills", skill), { recursive: true, force: true });
  }
  return backup;
}

function escapeRegex(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function normalize(text) {
  return text.replace(/\r\n/g, "\n").trim();
}

async function install(runRoot) {
  const home = codexHome();
  await fsp.mkdir(home, { recursive: true });
  const backup = await backupManaged(home, "install");
  const bundle = await fsp.readFile(path.join(runRoot, "codex-files", "codex-config-bundle", "AGENTS.md"), "utf8");
  const agentsPath = path.join(home, "AGENTS.md");
  let existing = (await exists(agentsPath)) ? await fsp.readFile(agentsPath, "utf8") : "";
  const managed = `${MANAGED_BEGIN}\n${bundle.trim()}\n${MANAGED_END}`;
  const block = new RegExp(`${escapeRegex(MANAGED_BEGIN)}[\\s\\S]*?${escapeRegex(MANAGED_END)}`, "m");
  existing = block.test(existing) ? existing.replace(block, managed) : `${existing.trimEnd()}${existing.trim() ? "\n\n" : ""}${managed}\n`;
  await fsp.writeFile(agentsPath, existing, "utf8");
  const configPath = path.join(home, "config.toml");
  if (await exists(configPath)) {
    let config = await fsp.readFile(configPath, "utf8");
    config = config.replace(/^\s*model_instructions_file\s*=\s*["']system-prompt\.md["']\s*(?:#.*)?\r?\n?/gmi, "");
    await fsp.writeFile(configPath, config, "utf8");
  }
  const skillRoot = path.join(home, "skills");
  await fsp.mkdir(skillRoot, { recursive: true });
  for (const skill of SKILLS) {
    const source = path.join(runRoot, "skills", skill);
    const target = path.join(skillRoot, skill);
    await fsp.rm(target, { recursive: true, force: true });
    await fsp.cp(source, target, { recursive: true, force: true });
  }
  const installedText = await fsp.readFile(agentsPath, "utf8");
  const match = installedText.match(block);
  if (!match || normalize(match[0]).includes(normalize(bundle)) === false) throw new Error("AGENTS 安装后验证失败。");
  for (const skill of SKILLS) if (!(await exists(path.join(skillRoot, skill, "SKILL.md")))) throw new Error(`Skill 安装验证失败：${skill}`);
  console.log(`[+] AGENTS 与 ${SKILLS.length} 个 Skill 安装完成`);
  console.log(`[+] 备份目录：${backup}`);
}

async function uninstall() {
  const home = codexHome();
  await fsp.mkdir(home, { recursive: true });
  const backup = await backupManaged(home, "uninstall");
  const agentsPath = path.join(home, "AGENTS.md");
  if (await exists(agentsPath)) {
    let existing = await fsp.readFile(agentsPath, "utf8");
    const block = new RegExp(`\\s*${escapeRegex(MANAGED_BEGIN)}[\\s\\S]*?${escapeRegex(MANAGED_END)}\\s*`, "m");
    existing = existing.replace(block, "\n").replace(/\n{3,}/g, "\n\n").trim();
    await fsp.writeFile(agentsPath, existing ? `${existing}\n` : "", "utf8");
  }
  for (const skill of SKILLS) await fsp.rm(path.join(home, "skills", skill), { recursive: true, force: true });
  console.log("[+] 海鸥受管 AGENTS 区块与 Skill 已卸载");
  console.log(`[+] 备份目录：${backup}`);
}

async function pause() {
  if (noPause || !process.stdin.isTTY) return;
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  try { await rl.question("\n按 Enter 键关闭窗口..."); } finally { rl.close(); }
}

async function main() {
  const major = Number(process.versions.node.split(".")[0]);
  banner();
  if (major < 18) throw new Error(`需要 Node.js 18 或更高版本，当前为 ${process.versions.node}`);
  const base = __dirname;
  const coreDir = path.join(base, ".core");
  let extracted;
  try {
    const manifest = await verifyRelease(coreDir);
    const releaseId = await verifyLauncherLock(base, coreDir);
    console.log("[+] Ed25519 发布签名有效");
    console.log(`[+] SHA-256 完整性验证通过：${manifest.file_count} 个文件`);
    console.log(`[+] 发布者指纹：${PUBLIC_KEY_SHA256.slice(0, 16)}...${PUBLIC_KEY_SHA256.slice(-16)}`);
    console.log(`[+] 启动器身份锁：${releaseId}`);
    console.log("[+] 发布模式：AES-256-GCM 加密包");
    if (args.has("--verify-only")) return 0;
    extracted = await decryptPayload(coreDir, manifest);
    console.log("[+] 加密数据包认证和解密通过");
    if (ACTION === "install") await install(extracted); else await uninstall();
    console.log("[+] 操作完成。完全重启 Codex 后生效。");
    console.log("[*] API 中转：https://zz.aiapi2025.top");
    return 0;
  } finally {
    if (extracted) await fsp.rm(extracted, { recursive: true, force: true });
  }
}

(async () => {
  let exitCode = 0;
  try {
    exitCode = await main();
  } catch (error) {
    exitCode = error instanceof IntegrityError ? 23 : 24;
    console.error(`[X] ${error.message}`);
    if (error instanceof IntegrityError) console.error("[X] 当前文件不是完整的官方签名版本。");
  }
  await pause();
  process.exitCode = exitCode;
})().catch(error => {
  console.error(`[X] ${error.message}`);
  process.exitCode = 24;
});